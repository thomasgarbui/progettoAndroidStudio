package com.example.servermorracineseadvanced;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerMorraCineseAdvancedApplicationTests {

    @Test
    void contextLoads() {
    }

}
